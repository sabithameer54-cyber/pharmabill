import {
  Medicine,
  Batch,
  Supplier,
  ScannedBillRecord,
  StockMovement,
  CustomerSale,
} from '../types';
import { generate8kPharmaDataset } from './pharmaGenerator';

export interface ShopStorageData {
  storeName: string;
  customMedicines: Medicine[];
  medicineUpdates: Record<string, Partial<Medicine>>;
  batchOverrides: Record<string, number>; // batchId -> remaining quantity
  userBatches: Batch[];
  suppliers: Supplier[];
  scannedBills: ScannedBillRecord[];
  movements: StockMovement[];
  sales: CustomerSale[];
  lastUpdated: string;
  hasInitialized8k?: boolean;
}

const filterOldMockBills = (bills: ScannedBillRecord[]): ScannedBillRecord[] => {
  return bills.filter((b) => {
    const sName = (b.supplierName || '').toLowerCase();
    const invNo = (b.invoiceNumber || '').toLowerCase();
    const isMock =
      sName.includes('aztech') ||
      sName.includes('western') ||
      sName.includes('victory') ||
      sName.includes('ajay') ||
      invNo.includes('g000938') ||
      invNo.includes('52143') ||
      invNo.includes('26001730068315') ||
      invNo.includes('apa-4532');
    return !isMock;
  });
};

const filterOldMockMovements = (movements: StockMovement[]): StockMovement[] => {
  return movements.filter((m) => {
    const notes = (m.notes || '').toLowerCase();
    const ref = (m.referenceId || '').toLowerCase();
    const isMock =
      notes.includes('aztech') ||
      notes.includes('western') ||
      notes.includes('victory') ||
      ref.includes('g000938') ||
      ref.includes('52143') ||
      ref.includes('26001730068315') ||
      ref.includes('apa-4532');
    return !isMock;
  });
};

export const DEFAULT_SUPPLIERS: Supplier[] = [];

/**
 * Salted hash function for store passwords
 */
function hashStorePassword(storeName: string, password: string): string {
  const shopKey = getShopKey(storeName);
  const salt = `pharmabill_salt_${shopKey}_2026`;
  const combined = `${salt}:${password.trim()}:${salt}`;
  let hash1 = 0x811c9dc5;
  let hash2 = 0x9e3779b9;
  for (let i = 0; i < combined.length; i++) {
    const char = combined.charCodeAt(i);
    hash1 ^= char;
    hash1 = Math.imul(hash1, 0x01000193);
    hash2 = Math.imul(hash2 ^ (char * 31), 0x85ebca6b);
    hash2 ^= hash2 >>> 13;
  }
  return `pb_h_${(hash1 >>> 0).toString(16)}_${(hash2 >>> 0).toString(16)}`;
}

/**
 * Checks if a store already has a set password
 */
export function hasStorePassword(storeName: string): boolean {
  const shopKey = getShopKey(storeName);
  const key = `pharmabill_pwd_${shopKey}`;
  return !!localStorage.getItem(key);
}

/**
 * Stores the password for a store
 */
export function setStorePassword(storeName: string, password: string): void {
  const shopKey = getShopKey(storeName);
  const key = `pharmabill_pwd_${shopKey}`;
  const hash = hashStorePassword(storeName, password);
  localStorage.setItem(key, hash);
}

/**
 * Resets or clears the password for a store
 */
export function resetStorePassword(storeName: string, newPassword?: string): void {
  const cleanStore = storeName.trim() || 'Sadi Medical';
  const shopKey = getShopKey(cleanStore);
  const key = `pharmabill_pwd_${shopKey}`;
  if (newPassword && newPassword.trim()) {
    setStorePassword(cleanStore, newPassword.trim());
  } else {
    try {
      localStorage.removeItem(key);
    } catch {}
  }
}

/**
 * Verifies the password for a store.
 * Any email can log into any store if the correct store password is provided.
 * If the store is newly accessed / registered, the entered password sets the store's password.
 */
export function verifyStorePassword(
  storeName: string,
  password: string
): { success: boolean; isNewStore: boolean; error?: string } {
  const cleanStore = storeName.trim() || 'Sadi Medical';
  const cleanPassword = password.trim();

  if (!cleanPassword) {
    return {
      success: false,
      isNewStore: false,
      error: 'Please enter the store password.',
    };
  }

  const shopKey = getShopKey(cleanStore);
  const key = `pharmabill_pwd_${shopKey}`;
  const existingHash = localStorage.getItem(key);

  if (!existingHash) {
    // New store initialization or uninitialized store: set the password!
    setStorePassword(cleanStore, cleanPassword);
    registerShopName(cleanStore);
    return { success: true, isNewStore: true };
  }

  const testHash = hashStorePassword(cleanStore, cleanPassword);
  if (testHash === existingHash) {
    return { success: true, isNewStore: false };
  }

  return {
    success: false,
    isNewStore: false,
    error: `Incorrect password for store "${cleanStore}". Use the password created for this store.`,
  };
}

/**
 * Active authenticated session management
 */
export function saveActiveSession(email: string, storeName: string): void {
  try {
    localStorage.setItem('pharmabill_auth_session_active', 'true');
    localStorage.setItem('pharmabill_auth_session_email', email.trim());
    localStorage.setItem('pharmabill_auth_session_store', storeName.trim());
    localStorage.setItem('pharmabill_user_email', email.trim());
    localStorage.setItem('pharmabill_store_name', storeName.trim());
  } catch {}
}

export function clearActiveSession(): void {
  try {
    localStorage.removeItem('pharmabill_auth_session_active');
    // Note: Do NOT delete store data or registered shop names!
  } catch {}
}

export function getActiveSession(): { isAuthenticated: boolean; email: string; storeName: string } {
  try {
    const isActive = localStorage.getItem('pharmabill_auth_session_active') === 'true';
    const email = localStorage.getItem('pharmabill_auth_session_email') || localStorage.getItem('pharmabill_user_email') || '';
    const storeName = localStorage.getItem('pharmabill_auth_session_store') || localStorage.getItem('pharmabill_store_name') || 'Sadi Medical';
    return { isAuthenticated: isActive, email, storeName };
  } catch {
    return { isAuthenticated: false, email: '', storeName: 'Sadi Medical' };
  }
}

/**
 * Normalizes a store name into a consistent storage key.
 * Example: "Sadi Medical", "sadi medikal", "  Sadi Medical  " -> "sadi_medical"
 */
export function getShopKey(storeName: string): string {
  const clean = (storeName || 'Sadi Medical').trim().toLowerCase();
  // Strip non-alphanumeric characters to handle minor spelling/spacing variations
  const normalized = clean.replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
  return normalized || 'sadi_medical';
}

/**
 * Retrieves the list of known registered shop names
 */
export function getKnownShops(): string[] {
  try {
    const raw = localStorage.getItem('pharmabill_known_shops');
    if (raw) {
      const list = JSON.parse(raw);
      if (Array.isArray(list) && list.length > 0) return list;
    }
  } catch {}
  return ['Sadi Medical'];
}

/**
 * Registers a shop name into the known shops list
 */
export function registerShopName(storeName: string): void {
  try {
    const clean = storeName.trim();
    if (!clean) return;
    const known = getKnownShops();
    const exists = known.some((s) => getShopKey(s) === getShopKey(clean));
    if (!exists) {
      const updated = [...known, clean];
      localStorage.setItem('pharmabill_known_shops', JSON.stringify(updated));
    }
  } catch {}
}

/**
 * Check if a shop has existing saved data in storage
 */
export function hasExistingShopData(storeName: string): boolean {
  try {
    const key = `pharmabill_shop_${getShopKey(storeName)}`;
    return !!localStorage.getItem(key);
  } catch {
    return false;
  }
}

/**
 * Load shop data.
 * When ANY user logs in with a different email using the SAME shop name,
 * this function retrieves the existing data for that shop.
 */
export function loadShopData(storeName: string): {
  medicines: Medicine[];
  batches: Batch[];
  suppliers: Supplier[];
  scannedBills: ScannedBillRecord[];
  movements: StockMovement[];
  sales: CustomerSale[];
  storeName: string;
} {
  const shopKey = getShopKey(storeName);
  const storageKey = `pharmabill_shop_${shopKey}`;

  let parsed: ShopStorageData | null = null;
  try {
    const saved = localStorage.getItem(storageKey);
    if (saved) {
      parsed = JSON.parse(saved);
    }
  } catch (e) {
    console.warn(`Error reading shop data for ${shopKey}:`, e);
  }

  // 1. Generate the foundational 8,000 medicines catalog across tablets, syrups, ointments, etc.
  const { medicines: base8kMeds, batches: base8kBatches } = generate8kPharmaDataset();

  if (!parsed) {
    // Brand new shop initialization:
    // Sort all 8,000 medicines strictly in alphabetical order
    const sortedMeds = base8kMeds.sort((a, b) =>
      a.name.localeCompare(b.name, undefined, { sensitivity: 'base' })
    );

    const initialData: ShopStorageData = {
      storeName: storeName.trim() || 'Sadi Medical',
      customMedicines: [],
      medicineUpdates: {},
      batchOverrides: {},
      userBatches: [],
      suppliers: DEFAULT_SUPPLIERS,
      scannedBills: [],
      movements: [],
      sales: [],
      lastUpdated: new Date().toISOString(),
      hasInitialized8k: true,
    };

    try {
      localStorage.setItem(storageKey, JSON.stringify(initialData));
      registerShopName(storeName);
    } catch (e) {
      console.warn('Error saving initial shop data:', e);
    }

    return {
      medicines: sortedMeds,
      batches: base8kBatches,
      suppliers: DEFAULT_SUPPLIERS,
      scannedBills: [],
      movements: [],
      sales: [],
      storeName: storeName.trim() || 'Sadi Medical',
    };
  }

  // 2. Re-hydrate existing shop data:
  // Apply any updates to the 8,000 base medicines
  const updates = parsed.medicineUpdates || {};
  const updatedBaseMeds = base8kMeds.map((med) => {
    if (updates[med.id]) {
      return { ...med, ...updates[med.id] };
    }
    return med;
  });

  // Merge custom medicines (e.g. newly inwarded from bills)
  const customMeds = (parsed.customMedicines || []).filter(
    (m) => !m.name.toUpperCase().includes('TELMIGET CT-40') && !m.name.toUpperCase().includes('VONOPOT-10') && !m.name.toUpperCase().includes('VILDUS-M FORTE') && !m.name.toUpperCase().includes('BIOTON-S')
  );
  const combinedMeds = [...updatedBaseMeds, ...customMeds];

  // Strictly sort the entire catalog in alphabetical order
  combinedMeds.sort((a, b) =>
    a.name.localeCompare(b.name, undefined, { sensitivity: 'base' })
  );

  // Apply batch stock overrides (e.g. quantity reductions from customer sales or inward additions)
  const batchOverrides = parsed.batchOverrides || {};
  const appliedBaseBatches = base8kBatches.map((b) => {
    if (batchOverrides[b.id] !== undefined) {
      return { ...b, quantity: batchOverrides[b.id] };
    }
    return b;
  });

  // Apply user created batches from scanned bills
  const userBatches = (parsed.userBatches || [])
    .filter((b) => !b.invoiceNumber?.includes('G000938') && !b.supplierName?.toUpperCase().includes('AZTECH'))
    .map((b) => {
      if (batchOverrides[b.id] !== undefined) {
        return { ...b, quantity: batchOverrides[b.id] };
      }
      return b;
    });

  const combinedBatches = [...userBatches, ...appliedBaseBatches];

  // Clean and ensure mock bills are filtered out from scannedBills
  const cleanedScannedBills = filterOldMockBills(parsed.scannedBills || []);

  // Clean and ensure mock movements are filtered out from movements
  const cleanedMovements = filterOldMockMovements(parsed.movements || []);

  const currentSuppliers = (parsed.suppliers && parsed.suppliers.length > 0 ? parsed.suppliers : DEFAULT_SUPPLIERS).filter(
    (s) => !s.name.toUpperCase().includes('AZTECH')
  );

  return {
    medicines: combinedMeds,
    batches: combinedBatches,
    suppliers: currentSuppliers.length > 0 ? currentSuppliers : DEFAULT_SUPPLIERS,
    scannedBills: cleanedScannedBills,
    movements: cleanedMovements,
    sales: parsed.sales || [],
    storeName: parsed.storeName || storeName,
  };
}

/**
 * Persists shop data safely.
 * Storing deltas keeps local storage usage small (< 100KB) while maintaining
 * full state across all 8,000 medicines.
 */
export function saveShopData(
  storeName: string,
  state: {
    medicines: Medicine[];
    batches: Batch[];
    suppliers: Supplier[];
    scannedBills: ScannedBillRecord[];
    movements: StockMovement[];
    sales: CustomerSale[];
  }
): void {
  const shopKey = getShopKey(storeName);
  const storageKey = `pharmabill_shop_${shopKey}`;

  try {
    // 1. Separate custom/inwarded medicines from standard 8,000 base catalog
    const customMeds = state.medicines.filter(
      (m) => !m.id.startsWith('med-8k-') || m.isFromBill
    );

    // 2. Track modified prices or fields on standard base medicines
    const medicineUpdates: Record<string, Partial<Medicine>> = {};
    for (const m of state.medicines) {
      if (m.id.startsWith('med-8k-') && m.isFromBill) {
        medicineUpdates[m.id] = {
          mrp: m.mrp,
          sellingPrice: m.sellingPrice,
          isFromBill: m.isFromBill,
          lastInwardBillId: m.lastInwardBillId,
          lastInwardDate: m.lastInwardDate,
        };
      }
    }

    // 3. Track batch overrides (including deductions when customers buy items)
    const batchOverrides: Record<string, number> = {};
    const userBatches: Batch[] = [];

    for (const b of state.batches) {
      if (b.id.startsWith('batch-8k-')) {
        // Record all quantity changes (e.g. customer buys reducing stock)
        batchOverrides[b.id] = b.quantity;
      } else {
        userBatches.push(b);
        batchOverrides[b.id] = b.quantity;
      }
    }

    const payload: ShopStorageData = {
      storeName: storeName.trim() || 'Sadi Medical',
      customMedicines: customMeds.slice(0, 1000),
      medicineUpdates,
      batchOverrides,
      userBatches: userBatches.slice(0, 1000),
      suppliers: state.suppliers,
      scannedBills: state.scannedBills,
      movements: state.movements.slice(0, 500),
      sales: state.sales.slice(0, 500),
      lastUpdated: new Date().toISOString(),
      hasInitialized8k: true,
    };

    localStorage.setItem(storageKey, JSON.stringify(payload));
    registerShopName(storeName);
  } catch (e) {
    console.warn(`Error saving shop data for ${shopKey}:`, e);
  }
}
