import React, { useState, useMemo } from 'react';
import { Mail, ShieldCheck, HeartPulse, Building2, ArrowRight, Database, CheckCircle2, Lock, Eye, EyeOff, KeyRound, RotateCcw, Sparkles } from 'lucide-react';
import { getKnownShops, hasExistingShopData, hasStorePassword, verifyStorePassword, resetStorePassword, setStorePassword } from '../utils/shopStorage';

interface UserLoginModalProps {
  isOpen: boolean;
  onClose?: () => void;
  onLogin: (email: string, storeName: string, password?: string) => void;
  currentEmail?: string;
  currentStoreName?: string;
}

export const UserLoginModal: React.FC<UserLoginModalProps> = ({
  isOpen,
  onClose,
  onLogin,
  currentEmail = '',
  currentStoreName = 'Sadi Medical',
}) => {
  const [email, setEmail] = useState(currentEmail || 'pharmacist@sadimedical.com');
  const [storeName, setStoreName] = useState(currentStoreName || 'Sadi Medical');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resetNotice, setResetNotice] = useState<string | null>(null);

  const knownShops = useMemo(() => getKnownShops(), [isOpen]);
  const hasExistingData = useMemo(() => hasExistingShopData(storeName), [storeName]);
  const hasExistingPwd = useMemo(() => hasStorePassword(storeName), [storeName]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = email.trim();
    const cleanStore = storeName.trim() || 'Sadi Medical';
    const cleanPassword = password.trim();

    if (!cleanEmail) {
      setError('Please enter your email address');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      setError('Please enter a valid email address');
      return;
    }
    if (!cleanPassword) {
      setError(`Please enter the store password for "${cleanStore}"`);
      return;
    }

    // Verify store-specific password
    const result = verifyStorePassword(cleanStore, cleanPassword);
    if (!result.success) {
      setError(result.error || `Incorrect password for store "${cleanStore}". Enter the password created for this store.`);
      return;
    }

    setError(null);
    onLogin(cleanEmail, cleanStore, cleanPassword);
  };

  const handleResetPassword = () => {
    const cleanStore = storeName.trim() || 'Sadi Medical';
    if (hasStorePassword(cleanStore)) {
      setError('For an existing store, the current store password is required. Resetting from the public login screen is disabled to prevent unauthorized access.');
      return;
    }
    const newPassword = window.prompt(`Create a password for "${cleanStore}" (minimum 6 characters):`) || '';
    if (newPassword.trim().length < 6) {
      setError('Password must contain at least 6 characters.');
      return;
    }
    setStorePassword(cleanStore, newPassword.trim());
    setPassword(newPassword.trim());
    setError(null);
    setResetNotice(`Password created for "${cleanStore}". Click Login below.`);
    setTimeout(() => setResetNotice(null), 6000);
  };

  const handleQuickDemoLogin = () => {
    const demoEmail = 'pharmacist@sadimedical.com';
    const demoStore = 'Sadi Medical';
    const demoPwd = '123456';
    setEmail(demoEmail);
    setStoreName(demoStore);
    setPassword(demoPwd);
    if (!hasStorePassword(demoStore)) setStorePassword(demoStore, demoPwd);
    setError(null);
    onLogin(demoEmail, demoStore, demoPwd);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-5 sm:p-6 shadow-2xl relative text-slate-100 max-h-[95vh] overflow-y-auto">
        <div className="flex items-center space-x-3 mb-5">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 p-0.5 shadow-lg shadow-emerald-500/20 flex items-center justify-center shrink-0">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <HeartPulse className="w-6 h-6 text-emerald-400" />
            </div>
          </div>
          <div>
            <h2 className="text-lg font-bold text-white flex items-center">
              PharmaBill Store Login
              <span className="ml-2 text-xs font-mono font-medium px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                Secure Store Access
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Sign in with Email + Store + Store Password. Any email can access a store with its store password.
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Email ID */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
              <span className="flex items-center">
                <Mail className="w-3.5 h-3.5 text-emerald-400 mr-1.5" />
                Email Address ID <span className="text-rose-400 ml-1">*</span>
              </span>
              <span className="text-[10px] text-slate-500">Any valid email</span>
            </label>
            <input
              id="login-email-input"
              type="email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                setError(null);
              }}
              placeholder="e.g. pharmacist@yourstore.com"
              required
              className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none transition"
            />
          </div>

          {/* Store Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
              <span className="flex items-center">
                <Building2 className="w-3.5 h-3.5 text-emerald-400 mr-1.5" />
                Store / Pharmacy Name <span className="text-rose-400 ml-1">*</span>
              </span>
              {hasExistingData ? (
                <span className="text-[11px] text-emerald-400 font-medium flex items-center space-x-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Isolated Store Data</span>
                </span>
              ) : (
                <span className="text-[11px] text-slate-500">New Store</span>
              )}
            </label>
            <input
              id="login-store-name-input"
              type="text"
              value={storeName}
              onChange={(e) => {
                setStoreName(e.target.value);
                setError(null);
              }}
              placeholder="e.g. Sadi Medical"
              required
              className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none transition"
            />
          </div>

          {/* Store-Specific Password */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
              <span className="flex items-center">
                <Lock className="w-3.5 h-3.5 text-emerald-400 mr-1.5" />
                Store Password <span className="text-rose-400 ml-1">*</span>
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                {hasExistingPwd ? 'Enter Store Password' : 'Set Password for this Store'}
              </span>
            </label>
            <div className="relative">
              <input
                id="login-store-password-input"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError(null);
                }}
                placeholder={hasExistingPwd ? `Password for "${storeName}"` : `Create password for "${storeName}"`}
                required
                className="w-full bg-slate-950 border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl pl-3.5 pr-10 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none transition font-mono"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-white transition"
                title={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {error && (
              <div className="p-2.5 bg-rose-950/80 border border-rose-500/40 rounded-xl text-xs text-rose-300 mt-2 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                <span className="font-semibold">{error}</span>
                {!hasExistingPwd && <button
                  type="button"
                  onClick={handleResetPassword}
                  className="px-3 py-1 bg-rose-900/60 hover:bg-rose-800 text-rose-200 border border-rose-500/40 rounded-lg text-[11px] font-bold shrink-0 transition flex items-center space-x-1 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Create Store Password</span>
                </button>}
              </div>
            )}
            {resetNotice && (
              <div className="p-2.5 bg-emerald-950/80 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 mt-2 flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span className="font-semibold">{resetNotice}</span>
              </div>
            )}
          </div>

          {/* Data Status Box */}
          <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl text-xs text-slate-400">
            <div className="flex items-start space-x-2">
              <Database className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
              <div>
                <span className="font-semibold text-white">
                  Isolated Store Database: "{storeName}"
                </span>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Store data is strictly isolated. Users with this store's password gain access to its catalog, bills, suppliers, and ledger.
                </p>
              </div>
            </div>
          </div>

          {/* Registered Stores selector */}
          <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800/80 space-y-2">
            <span className="text-[11px] text-slate-400 font-medium block">Switch to Known Store:</span>
            <div className="flex flex-wrap gap-1.5">
              {knownShops.map((shop) => (
                <button
                  key={shop}
                  type="button"
                  onClick={() => {
                    setStoreName(shop);
                    setError(null);
                  }}
                  className={`text-xs px-2.5 py-1 rounded-lg border transition font-mono ${
                    storeName.trim().toLowerCase() === shop.trim().toLowerCase()
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 font-bold'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                  }`}
                >
                  🏪 {shop}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
            <button
              type="button"
              onClick={handleQuickDemoLogin}
              className="px-3.5 py-2 bg-gradient-to-r from-emerald-600/30 to-teal-600/30 hover:from-emerald-600/50 hover:to-teal-600/50 text-emerald-300 border border-emerald-500/40 text-xs font-bold rounded-xl transition flex items-center space-x-1.5 cursor-pointer shadow-sm"
              title="One-click sign in with demo credentials"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>Quick Demo Sign-In</span>
            </button>

            <div className="flex items-center space-x-2">
              {onClose && (
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-slate-200 transition"
                >
                  Cancel
                </button>
              )}
              <button
                id="submit-login-btn"
                type="submit"
                className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold rounded-xl shadow-lg shadow-emerald-500/20 transition flex items-center space-x-2 cursor-pointer"
              >
                <KeyRound className="w-4 h-4" />
                <span>Login to Store</span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </button>
            </div>
          </div>
        </form>

        <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-center text-[11px] text-slate-500 space-x-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Strict store data isolation with store-specific password security</span>
        </div>
      </div>
    </div>
  );
};

