import React, { useMemo, useState } from 'react';
import { ArrowLeft, Building2, Calendar, Mail, Pill, Search, ShieldCheck, UserRound, X } from 'lucide-react';
import { CustomerSale } from '../types';
import { getKnownShops, getShopKey, hasExistingShopData, loadShopData } from '../utils/shopStorage';

interface CustomerPortalViewProps { onBack: () => void; }

const normalizeEmail = (value: string) => value.trim().toLowerCase();

export const CustomerPortalView: React.FC<CustomerPortalViewProps> = ({ onBack }) => {
  const [storeQuery, setStoreQuery] = useState('');
  const [selectedStore, setSelectedStore] = useState('');
  const [email, setEmail] = useState('');
  const [history, setHistory] = useState<CustomerSale[]>([]);
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState('');

  const stores = useMemo(() => {
    const q = storeQuery.trim().toLowerCase();
    return getKnownShops().filter((name) => !q || name.toLowerCase().includes(q)).slice(0, 20);
  }, [storeQuery]);

  const lookup = () => {
    const cleanStore = selectedStore.trim();
    const cleanEmail = normalizeEmail(email);
    setError(''); setSearched(true); setHistory([]);
    if (!cleanStore) return setError('Search and select a store first.');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) return setError('Enter the same email address used at the pharmacy.');
    if (!hasExistingShopData(cleanStore)) return setError('That store has no saved customer records on this device.');
    try {
      const data = loadShopData(cleanStore);
      const matches = (data.sales || []).filter((sale) => normalizeEmail(sale.customerEmail || '') === cleanEmail);
      setHistory(matches.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    } catch { setError('Could not read this store history. Please try again.'); }
  };

  const totalSpent = history.reduce((sum, sale) => sum + (sale.grandTotal || 0), 0);
  const itemCount = history.reduce((sum, sale) => sum + sale.items.reduce((n, item) => n + item.quantity, 0), 0);

  return <div className="min-h-screen bg-slate-950 text-slate-100 p-3 sm:p-6">
    <div className="max-w-5xl mx-auto">
      <header className="flex flex-wrap items-center justify-between gap-3 mb-5">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center"><Pill className="w-6 h-6 text-emerald-400" /></div>
          <div><h1 className="text-xl font-black">PharmaBill Customer Account</h1><p className="text-xs text-slate-400">View only your own purchase history</p></div>
        </div>
        <button onClick={onBack} className="px-3 py-2 rounded-xl border border-slate-700 hover:border-emerald-500 text-xs font-bold flex items-center gap-2"><ArrowLeft className="w-4 h-4"/> Store Login</button>
      </header>

      <section className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 mb-5">
        <div className="flex items-start gap-3 mb-4"><ShieldCheck className="w-5 h-5 text-emerald-400 mt-0.5"/><div><h2 className="font-bold">Private customer lookup</h2><p className="text-xs text-slate-400 mt-1">Customers cannot use this portal to manage medicines, suppliers, stock, bills, or store settings. The lookup only matches sales recorded against the entered email.</p></div></div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div><label className="text-[11px] font-bold text-slate-300">Search Store Name</label><div className="relative mt-1"><Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500"/><input value={storeQuery} onChange={e=>{setStoreQuery(e.target.value);setSelectedStore('');}} placeholder="e.g. Sadi Medical" className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm outline-none focus:border-emerald-500"/></div>
            {storeQuery && stores.length > 0 && <div className="mt-1 max-h-36 overflow-auto rounded-xl border border-slate-700 bg-slate-950">{stores.map(store=><button key={getShopKey(store)} onClick={()=>{setSelectedStore(store);setStoreQuery(store);}} className="w-full text-left px-3 py-2 text-sm hover:bg-slate-800 flex items-center gap-2"><Building2 className="w-4 h-4 text-emerald-400"/>{store}</button>)}</div>}
          </div>
          <div><label className="text-[11px] font-bold text-slate-300">Customer Email ID</label><div className="relative mt-1"><Mail className="absolute left-3 top-2.5 w-4 h-4 text-slate-500"/><input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="customer@example.com" className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm outline-none focus:border-emerald-500"/></div></div>
        </div>
        {error && <div className="mt-3 p-3 rounded-xl bg-rose-950/50 border border-rose-500/30 text-rose-300 text-xs font-semibold">{error}</div>}
        <button onClick={lookup} className="mt-4 w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-500 text-slate-950 font-black text-sm hover:bg-emerald-400">View My Purchase History</button>
      </section>

      {searched && !error && <section>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3"><p className="text-[10px] text-slate-500 uppercase">Bills</p><p className="text-xl font-black">{history.length}</p></div>
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3"><p className="text-[10px] text-slate-500 uppercase">Items purchased</p><p className="text-xl font-black">{itemCount}</p></div>
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 col-span-2 sm:col-span-1"><p className="text-[10px] text-slate-500 uppercase">Total spent</p><p className="text-xl font-black">₹{totalSpent.toFixed(2)}</p></div>
        </div>
        {history.length === 0 ? <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-400"><UserRound className="w-8 h-8 mx-auto mb-2 opacity-50"/><p className="font-semibold">No purchases found for this email at this store.</p><p className="text-xs mt-1">Only completed sales linked to the exact email can appear here.</p></div> : <div className="space-y-3">{history.map(sale=><article key={sale.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-4"><div className="flex flex-wrap items-center justify-between gap-2 mb-3"><div><h3 className="font-black">{sale.invoiceNumber}</h3><p className="text-[11px] text-slate-500 flex items-center gap-1"><Calendar className="w-3 h-3"/>{new Date(sale.date).toLocaleString()}</p></div><span className="font-black text-emerald-400">₹{sale.grandTotal.toFixed(2)}</span></div><div className="divide-y divide-slate-800">{sale.items.map((item,idx)=><div key={`${sale.id}-${idx}`} className="py-2 flex flex-wrap items-center justify-between gap-2"><div><p className="text-sm font-bold">{item.medicineName}</p><p className="text-[11px] text-slate-500">{item.saleUnit === 'TABLET' ? `${item.quantity} loose tablet(s)` : `${item.quantity} pack(s)`} • Batch {item.batchNumber}</p></div><span className="text-xs font-mono">₹{item.lineTotal.toFixed(2)}</span></div>)}</div></article>)}</div>}
      </section>}
    </div>
  </div>;
};
